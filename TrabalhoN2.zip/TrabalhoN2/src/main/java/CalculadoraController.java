
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CalculadoraController {
    private final CalculadoraModel model;
    private final CalculadoraView view;

    public CalculadoraController(CalculadoraModel model, CalculadoraView view) {
        this.model = model;
        this.view = view;

        this.view.addSomarListener(new SomarListener());
        this.view.addSubtrairListener(new SubtrairListener());
        this.view.addMultiplicarListener(new MultiplicarListener());
        this.view.addDividirListener(new DividirListener());
        this.view.addExponenciarListener(new ExponenciarListener());
        this.view.addRaizQuadradaListener(new RaizQuadradaListener());
        this.view.addPorcentagemListener(new PorcentagemListener());
        this.view.addGerarRelatorioListener(new GerarRelatorioListener());
    }

    class SomarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.somar(view.getNumero1(), view.getNumero2());
            view.setResultado(resultado);
        }
    }

    class SubtrairListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.subtrair(view.getNumero1(), view.getNumero2());
            view.setResultado(resultado);
        }
    }

    class MultiplicarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.multiplicar(view.getNumero1(), view.getNumero2());
            view.setResultado(resultado);
        }
    }

    class DividirListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                double resultado = model.dividir(view.getNumero1(), view.getNumero2());
                view.setResultado(resultado);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(view, ex.getMessage());
            }
        }
    }

    class ExponenciarListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.exponenciar(view.getNumero1(), view.getNumero2());
            view.setResultado(resultado);
        }
    }

    class RaizQuadradaListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.raizQuadrada(view.getNumero1());
            view.setResultado(resultado);
        }
    }

    class PorcentagemListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double resultado = model.porcentagem(view.getNumero1(), view.getNumero2());
            view.setResultado(resultado);
        }
    }

    class GerarRelatorioListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            OperacaoCSV.salvarOperacoes(model.getOperacoes());
            JOptionPane.showMessageDialog(view, "Relatório gerado com sucesso em operacoes.csv");
        }
    }
}
