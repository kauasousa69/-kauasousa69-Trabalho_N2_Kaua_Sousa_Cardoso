
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

import java.util.ArrayList;
import java.util.List;

public class CalculadoraModel {
    private List<String> operacoes;

    public CalculadoraModel() {
        operacoes = new ArrayList<>();
    }

    public double somar(double a, double b) {
        double resultado = a + b;
        operacoes.add(a + " + " + b + " = " + resultado);
        return resultado;
    }

    public double subtrair(double a, double b) {
        double resultado = a - b;
        operacoes.add(a + " - " + b + " = " + resultado);
        return resultado;
    }

    public double multiplicar(double a, double b) {
        double resultado = a * b;
        operacoes.add(a + " * " + b + " = " + resultado);
        return resultado;
    }

    public double dividir(double a, double b) {
        if (b != 0) {
            double resultado = a / b;
            operacoes.add(a + " / " + b + " = " + resultado);
            return resultado;
        } else {
            throw new IllegalArgumentException("Divisão por zero não é permitida.");
        }
    }

    public double exponenciar(double base, double expoente) {
        double resultado = Math.pow(base, expoente);
        operacoes.add(base + " ^ " + expoente + " = " + resultado);
        return resultado;
    }

    public double raizQuadrada(double a) {
        double resultado = Math.sqrt(a);
        operacoes.add("√" + a + " = " + resultado);
        return resultado;
    }

    public double porcentagem(double total, double porcentagem) {
        double resultado = (total * porcentagem) / 100;
        operacoes.add(porcentagem + "% de " + total + " = " + resultado);
        return resultado;
    }

    public List<String> getOperacoes() {
        return operacoes;
    }
}
