
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

public class Main {
    public static void main(String[] args) {
        CalculadoraModel model = new CalculadoraModel();
        CalculadoraView view = new CalculadoraView();
        new CalculadoraController(model, view);
    }
}
